package member.ui;

public class MemberMain {

	public static void main(String[] args) {
		MemberUI ui = new MemberUI();
		
	}

}
